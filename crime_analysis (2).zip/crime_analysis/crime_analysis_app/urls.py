from django.urls import path
from . import views

urlpatterns = [
    path('load-dataset/', views.load_dataset, name='load_dataset'),
    path('temporal-analysis/', views.temporal_analysis_visualization, name='temporal_analysis'),
    path('geospatial-analysis/', views.geospatial_analysis, name='geospatial_analysis'),
    path('victim-demographic-analysis/', views.victim_demographics_analysis, name='victim_demographics_analysis'),
    path('combined-analysis/', views.combined_analysis, name='combined_analysis'),
    path('new_dataframe/', views.create_new_dataframe, name='new_dataframe'),
    path('linear_regression/', views.train_linear_regression, name='linear_regression_results'),  # Updated path
    path('gradient-boost-dataframe/', views.create_gradient_boost_dataframe, name='create_gradient_boost_dataframe'),
    path('gradient-boost-results/', views.train_gradient_boost, name='train_gradient_boost'),
    path('probabilities-prediction/', views.predict_probabilities, name='predict_probabilities'),
    path('models_used/', views.models_used, name='models_used'),
]
