from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
import matplotlib.pyplot as plt
# Import other necessary libraries for visualization and prediction



import requests
import pandas as pd
from django.shortcuts import render
from django.http import HttpResponse

from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt
import seaborn as sns
import folium
from folium.plugins import HeatMap, MarkerCluster
import plotly.graph_objs as go



import os
from django.conf import settings
import io
import urllib, base64

from django.shortcuts import render
import pandas as pd
import matplotlib.pyplot as plt
import io
import urllib, base64

import base64
import io
from io import BytesIO
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend (e.g., Agg)


def index(request):
    return render(request, 'crime_analysis_app/index.html')

# views.py

from django.shortcuts import render

def models_used(request):
    return render(request, 'models_used.html')


def load_dataset(request):
    if request.method == 'POST':
        url = request.POST.get('url')  # Get the URL from the form data
        if url:
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                df = pd.DataFrame(data)
                # Save DataFrame as CSV file in a folder within the project directory
                csv_folder = os.path.join(settings.BASE_DIR, 'datasets')  # Folder path to save CSV file
                os.makedirs(csv_folder, exist_ok=True)  # Create folder if it doesn't exist
                csv_file_path = os.path.join(csv_folder, 'dataset.csv')
                df.to_csv(csv_file_path, index=False)  # Save DataFrame as CSV file
                # Perform any additional processing if needed
                context = {'df': df}
                return render(request, 'display_dataset.html', context)
            else:
                return HttpResponse("Failed to fetch data from the provided URL")
        else:
            return HttpResponse("Please provide a URL")
    else:
        return render(request, 'load_dataset.html')






def temporal_analysis_visualization(request):
    # Load the CSV file from the folder
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')  # Folder path where CSV file is saved
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
        print("DataFrame shape:", df.shape)

        # Convert date and time columns to datetime format
        df['cmplnt_fr_dt'] = pd.to_datetime(df['cmplnt_fr_dt'])
        df['cmplnt_fr_tm'] = pd.to_datetime(df['cmplnt_fr_tm'])

        # Perform temporal analysis visualization using the DataFrame
        if not df.empty:
            # Extract month from 'cmplnt_fr_dt' and count frequency of crimes per month
            crimes_per_month = df['cmplnt_fr_dt'].dt.month.value_counts().sort_index()
            # Plot time series plot for frequency of crimes per month
            plt.figure(figsize=(10, 6))
            crimes_per_month.plot(kind='line', marker='o', color='blue')
            plt.title('Frequency of Crimes per Month')
            plt.xlabel('Month')
            plt.ylabel('Number of Crimes')
            plt.xticks(range(1, 13), ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            buffer1 = io.BytesIO()
            plt.savefig(buffer1, format='png')
            buffer1.seek(0)
            image_base64_1 = base64.b64encode(buffer1.getvalue()).decode()
            plt.close()

            # Extract day of the week from 'cmplnt_fr_dt' and count frequency of crimes per day of the week
            crimes_per_dayofweek = df['cmplnt_fr_dt'].dt.dayofweek.value_counts().sort_index()
            # Plot time series plot for frequency of crimes per day of the week
            plt.figure(figsize=(10, 6))
            crimes_per_dayofweek.plot(kind='line', marker='o', color='green')
            plt.title('Frequency of Crimes per Day of the Week')
            plt.xlabel('Day of the Week')
            plt.ylabel('Number of Crimes')
            plt.xticks(range(7), ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            buffer2 = io.BytesIO()
            plt.savefig(buffer2, format='png')
            buffer2.seek(0)
            image_base64_2 = base64.b64encode(buffer2.getvalue()).decode()
            plt.close()

            # Extract hour from 'cmplnt_fr_tm' column and count frequency of crimes per hour of the day
            crimes_per_hour = df['cmplnt_fr_tm'].dt.hour.value_counts().sort_index()
            # Plot time series plot for frequency of crimes per hour of the day
            plt.figure(figsize=(10, 6))
            crimes_per_hour.plot(kind='line', marker='o', color='orange')
            plt.title('Frequency of Crimes per Hour of the Day')
            plt.xlabel('Hour of the Day')
            plt.ylabel('Number of Crimes')
            plt.xticks(range(24))
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            buffer3 = io.BytesIO()
            plt.savefig(buffer3, format='png')
            buffer3.seek(0)
            image_base64_3 = base64.b64encode(buffer3.getvalue()).decode()
            plt.close()

            context = {
                'image_base64_1': image_base64_1,
                'image_base64_2': image_base64_2,
                'image_base64_3': image_base64_3,
            }
            return render(request, 'temporal_analysis.html', context)
        else:
            return HttpResponse("No data available in the CSV file.")
    else:
        return HttpResponse("CSV file does not exist.")





def geospatial_analysis(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')  # Folder path where CSV file is saved
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
        print("DataFrame shape:", df.shape)

        # Heatmap to visualize areas with high density of crimes
        nyc_map_heatmap = folium.Map(location=[40.7128, -74.0060], zoom_start=10)
        heat_data = [[row['latitude'], row['longitude']] for index, row in df.iterrows()]
        HeatMap(heat_data).add_to(nyc_map_heatmap)
        heatmap_html = nyc_map_heatmap._repr_html_()

        # Clustering algorithms to identify spatial clusters or hotspots of criminal activity
        nyc_map_clusters = folium.Map(location=[40.7128, -74.0060], zoom_start=10)
        marker_cluster = MarkerCluster().add_to(nyc_map_clusters)
        for index, row in df.iterrows():
            folium.Marker([row['latitude'], row['longitude']]).add_to(marker_cluster)
        clusters_html = nyc_map_clusters._repr_html_()

        # Crime locations with crime details using Plotly
        trace = go.Scattermapbox(
            lat=df['latitude'],
            lon=df['longitude'],
            mode='markers',
            marker=dict(
                size=8,
                color='red',
                opacity=0.8
            ),
            text=df.apply(lambda row: f"Race: {row['vic_race']}<br>"
                                       f"Age Group: {row['vic_age_group']}<br>"
                                       f"PD Description: {row['pd_desc']}", axis=1),
        )
        layout = go.Layout(
            title='Crime Locations in NYC',
            autosize=True,
            hovermode='closest',
            mapbox=dict(
                style='carto-positron',
                center=dict(
                    lat=40.7128,
                    lon=-74.0060
                ),
                zoom=10
            ),
        )
        fig = go.Figure(data=[trace], layout=layout)
        plotly_html = fig.to_html(full_html=False, default_height=500, default_width=700)

        # Crime spread per borough heat map
        boroughs = ['BROOKLYN', 'MANHATTAN', 'QUEENS', 'BRONX', 'STATEN ISLAND']
        borough_maps = []
        for borough in boroughs:
            nyc_map = folium.Map(location=[40.7128, -74.0060], zoom_start=10)
            borough_data = df[df['boro_nm'] == borough]
            heat_data = borough_data[['latitude', 'longitude']].values.tolist()
            HeatMap(heat_data).add_to(nyc_map)
            borough_maps.append(nyc_map)
        boroughs_html = [map._repr_html_() for map in borough_maps]

        # Crime counts per precinct
        crime_per_precinct = df['addr_pct_cd'].value_counts()
        plt.figure(figsize=(12, 6))
        crime_per_precinct.plot(kind='bar', color='orange')
        plt.title('Number of Crimes per Precinct')
        plt.xlabel('Precinct Code')
        plt.ylabel('Number of Crimes Reported')
        plt.xticks(rotation=90)
        buffer1 = io.BytesIO()
        plt.savefig(buffer1, format='png')
        buffer1.seek(0)
        precinct_counts_base64 = base64.b64encode(buffer1.getvalue()).decode()
        plt.close()

        # Crime count per borough pie chart
        crimes_per_borough = df['boro_nm'].value_counts()
        plt.figure(figsize=(8, 8))
        plt.pie(crimes_per_borough, labels=crimes_per_borough.index, autopct='%1.1f%%', startangle=140)
        plt.title('Number of Crimes per Borough')
        plt.axis('equal')
        buffer2 = io.BytesIO()
        plt.savefig(buffer2, format='png')
        buffer2.seek(0)
        borough_pie_base64 = base64.b64encode(buffer2.getvalue()).decode()
        plt.close()

        return render(request, 'geospatial_analysis.html', {
            'heatmap_html': heatmap_html,
            'clusters_html': clusters_html,
            'plotly_html': plotly_html,
            'boroughs_html': boroughs_html,
            'precinct_counts_base64': precinct_counts_base64,
            'borough_pie_base64': borough_pie_base64
        })
    else:
        return HttpResponse("CSV file does not exist.")



# views.py


def victim_demographics_analysis(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')  # Folder path where CSV file is saved
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
        print("DataFrame shape:", df.shape)

        # Victim Age Analysis
        crimes_by_age_group = df['vic_age_group'].value_counts()
        age_group_plot = generate_bar_plot(crimes_by_age_group, 'Distribution of Victim Age Groups', 'Age Group', 'Number of Crimes')

        # Victim Sex Analysis
        crimes_by_sex = df['vic_sex'].value_counts()
        sex_plot = generate_bar_plot(crimes_by_sex, 'Number of Crimes by Victim Sex', 'Sex', 'Number of Crimes')

        # Victim Race Analysis
        crimes_by_race = df['vic_race'].value_counts()
        race_plot = generate_bar_plot(crimes_by_race, 'Number of Crimes by Victim Race', 'Race', 'Number of Crimes')

        return render(request, 'victim_demographics_analysis.html', {
            'age_group_plot': age_group_plot,
            'sex_plot': sex_plot,
            'race_plot': race_plot
        })
    else:
        return HttpResponse("CSV file does not exist.")

def generate_bar_plot(data, title, xlabel, ylabel):
    plt.figure(figsize=(10, 6))
    data.plot(kind='bar', color='skyblue', edgecolor='black')
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xticks(rotation=45)

    # Convert plot to image
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()

    return image_base64





def combined_analysis(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')  # Folder path where CSV file is saved
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
        print("DataFrame shape:", df.shape)
    else:
        return render(request, 'error.html', {'message': 'CSV file does not exist.'})

    plots = {}

    # Number of Crimes by Victim Race, Sex, and Borough
    plots['crimes_by_borough_race_sex'] = generate_stacked_bar_plot(df.groupby(['boro_nm', 'vic_race', 'vic_sex']).size().unstack(),
                                                                    'Number of Crimes by Victim Race, Sex, and Borough',
                                                                    'Borough', 'Number of Crimes', rotation=45)

    # Victim Age Group per Borough
    plots['crimes_by_borough_age'] = generate_stacked_bar_plot(df.groupby(['boro_nm', 'vic_age_group']).size().unstack(),
                                                                'Number of Crimes per Victim Age Group and Borough',
                                                                'Borough', 'Number of Crimes', rotation=45)

    # Top Offense Descriptions
    top_n = 15
    top_offense_desc = df['ofns_desc'].value_counts().head(top_n)
    plots['top_offense_desc'] = generate_horizontal_bar_plot(top_offense_desc,
                                                             'Top {} Offense Descriptions'.format(top_n),
                                                             'Number of Crimes Reported', 'Offense Description')

    # Number of Crimes per Victim Race and Borough
    plots['crimes_by_borough_race'] = generate_clustered_bar_plot(df.groupby(['boro_nm', 'vic_race']).size().unstack(),
                                                                   'Number of Crimes per Victim Race and Borough',
                                                                   'Borough', 'Number of Crimes', rotation=45)

    # Number of Crimes per Victim Sex and Borough
    plots['crimes_by_borough_sex'] = generate_grouped_bar_plot(df.groupby(['boro_nm', 'vic_sex']).size().unstack(),
                                                               'Number of Crimes per Victim Sex and Borough',
                                                               'Borough', 'Number of Crimes', rotation=45)

    # Number of Crimes per Victim Race and Sex
    plots['crimes_by_race_sex'] = generate_grouped_bar_plot(df.groupby(['vic_race', 'vic_sex']).size().unstack(),
                                                             'Number of Crimes per Victim Race and Sex',
                                                             'Victim Race', 'Number of Crimes', rotation=45)

    return render(request, 'combined_analysis.html', {'plots': plots})

# Remaining functions remain the same as before...

def generate_stacked_bar_plot(data, title, xlabel, ylabel, rotation=None):
    plt.figure(figsize=(12, 8))
    data.plot(kind='bar', stacked=True, figsize=(12, 8))
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if rotation is not None:
        plt.xticks(rotation=rotation)
    plt.legend(title='Legend')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()
    return image_base64

def generate_horizontal_bar_plot(data, title, xlabel, ylabel):
    plt.figure(figsize=(10, 6))
    data.plot(kind='barh', color='skyblue')
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.gca().invert_yaxis()
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()
    return image_base64

def generate_clustered_bar_plot(data, title, xlabel, ylabel, rotation=None):
    plt.figure(figsize=(12, 8))
    data.plot(kind='bar', figsize=(12, 8))
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if rotation is not None:
        plt.xticks(rotation=rotation)
    plt.legend(title='Legend')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()
    return image_base64

def generate_grouped_bar_plot(data, title, xlabel, ylabel, rotation=None):
    plt.figure(figsize=(12, 8))
    data.plot(kind='bar', figsize=(12, 8))
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if rotation is not None:
        plt.xticks(rotation=rotation)
    plt.legend(title='Legend')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()
    return image_base64



populations = {'MANHATTAN': 1628706, 'BRONX': 1432132, 'BROOKLYN': 2582830, 'QUEENS': 2278906, 'STATEN ISLAND': 476143}



def create_new_dataframe(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)

        # Code to create a new data frame for linear regression
        # Assuming df is your DataFrame
        # Convert 'cmplnt_fr_tm' column to datetime format
        df['cmplnt_fr_tm'] = pd.to_datetime(df['cmplnt_fr_tm'], format='%H:%M:%S').dt.time

        # Extract hour from 'cmplnt_fr_tm' column
        df['hour'] = df['cmplnt_fr_tm'].apply(lambda x: x.hour)

        # Create pivot tables to get counts of crimes for each hour, borough, victim age group, and victim sex
        pivot_borough = pd.pivot_table(df, index='hour', columns='boro_nm', aggfunc='size', fill_value=0)
        pivot_age_group = pd.pivot_table(df, index='hour', columns='vic_age_group', aggfunc='size', fill_value=0)
        pivot_sex = pd.pivot_table(df, index='hour', columns='vic_sex', aggfunc='size', fill_value=0)

        # Merge pivot tables
        merged_df = pd.concat([pivot_borough, pivot_age_group, pivot_sex], axis=1)

        # Rename columns for clarity
        merged_df.columns = [f'{col}_crime_count' for col in merged_df.columns]

        # Reset index to make 'hour' a column instead of index
        merged_df.reset_index(inplace=True)

        # Pass the merged DataFrame to the template context
        context = {'merged_df': merged_df}

        # Render the template with the DataFrame
        return render(request, 'new_dataframe.html', context)
    else:
        return HttpResponse("CSV file does not exist.")







def train_linear_regression(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)

        # Convert 'cmplnt_fr_tm' column to datetime format
        df['cmplnt_fr_tm'] = pd.to_datetime(df['cmplnt_fr_tm'], format='%H:%M:%S').dt.time

        # Extract hour from 'cmplnt_fr_tm' column
        df['hour'] = df['cmplnt_fr_tm'].apply(lambda x: x.hour)

        # Create pivot tables to get counts of crimes for each hour, borough, victim age group, and victim sex
        pivot_borough = pd.pivot_table(df, index='hour', columns='boro_nm', aggfunc='size', fill_value=0)
        pivot_age_group = pd.pivot_table(df, index='hour', columns='vic_age_group', aggfunc='size', fill_value=0)
        pivot_sex = pd.pivot_table(df, index='hour', columns='vic_sex', aggfunc='size', fill_value=0)

        # Merge pivot tables
        merged_df = pd.concat([pivot_borough, pivot_age_group, pivot_sex], axis=1)

        # Rename columns for clarity
        merged_df.columns = [f'{col}_crime_count' for col in merged_df.columns]

        # Reset index to make 'hour' a column instead of index
        merged_df.reset_index(inplace=True)

        # Define features (X) and target variable (y)
        features_to_drop = ['hour', '18-24_crime_count']  # Add other columns to drop if needed
        X = merged_df.drop(columns=features_to_drop)
        y = merged_df['18-24_crime_count']  # Target variable

        # Split the dataset into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Create a linear regression model
        model = LinearRegression()

        # Fit the model to the training data
        model.fit(X_train, y_train)

        # Predict on the testing data
        y_pred = model.predict(X_test)

        # Evaluate the model
        mse = mean_squared_error(y_test, y_pred)
        r_squared = model.score(X_test, y_test)

        # Visualization: Scatter plot of actual vs predicted values
        plt.figure(figsize=(10, 6))
        plt.scatter(y_test, y_pred, color='blue')
        plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', linestyle='--')
        plt.title('Actual vs Predicted Values')
        plt.xlabel('Actual')
        plt.ylabel('Predicted')
        plt.grid(True)
        plt.tight_layout()

        # Save the plot to a buffer and encode as base64
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        plt.close()

        # Pass the image_base64 to the template
        context = {'mse': mse, 'r_squared': r_squared, 'scatter_plot': image_base64}
        return render(request, 'linear_regression_results.html', context)
    else:
        return HttpResponse("CSV file does not exist.")







def create_gradient_boost_dataframe(request):

    import pandas as pd


    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
    else:
        return HttpResponse("CSV file does not exist.")
    
    # Define populations dictionary
    populations = {'MANHATTAN': 1628706, 'BRONX': 1432132, 'BROOKLYN': 2582830, 'QUEENS': 2278906, 'STATEN ISLAND': 476143}

    # Initialize an empty DataFrame
    borough_df = pd.DataFrame(columns=['Borough', 'Total Crimes', 'Population', 'Crimes per Population'])

    # Drop rows with null values in the 'boro_nm' column
    df_cleaned = df.dropna(subset=['boro_nm'])

    # Calculate total number of crimes in each borough
    total_crimes = df_cleaned.groupby('boro_nm').size().reset_index(name='Total Crimes')

    # Add population data for each borough
    borough_df['Borough'] = total_crimes['boro_nm']
    borough_df['Total Crimes'] = total_crimes['Total Crimes']
    borough_df['Population'] = borough_df['Borough'].map(populations)

    # Drop rows with NaN population values
    borough_df = borough_df.dropna(subset=['Population'])

    # Calculate crimes per population ratio
    borough_df['Crimes per Population'] = borough_df['Total Crimes'] / borough_df['Population']

    # Iterate over the unique values of the 'law_cat_cd' column
    for law_cat_cd in df['law_cat_cd'].unique():
        # Filter DataFrame for the current 'law_cat_cd'
        df_law_cat_cd = df[df['law_cat_cd'] == law_cat_cd]
        # Calculate total number of crimes for the current 'law_cat_cd' in each borough
        total_crimes_law_cat_cd = df_law_cat_cd.groupby('boro_nm').size().reset_index(name=f'Total Crimes ({law_cat_cd})')
        # Merge with existing DataFrame on 'Borough' column
        borough_df = pd.merge(borough_df, total_crimes_law_cat_cd, left_on='Borough', right_on='boro_nm', how='left')

    # Fill NaN values with 0
    borough_df = borough_df.fillna(0)

    # drop 3 columns named  boro_nm_x  , boro_nm_y, boro_nm  from  borough_df
    borough_df.drop(columns=['boro_nm_x', 'boro_nm_y', 'boro_nm'], inplace=True)


    # Assuming you have a context dictionary containing data to pass to the template
    context = {'borough_df': borough_df}
    return render(request, 'gradient_boost_dataframe.html', context)






def calculate_accuracy(y_true, y_pred, threshold):
    y_pred_binary = (y_pred > threshold).astype(int)
    y_true_binary = (y_true > threshold).astype(int)
    accuracy = (y_pred_binary == y_true_binary).mean()
    return accuracy

def train_gradient_boost(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
    else:
        return HttpResponse("CSV file does not exist.")
    
    # Define populations dictionary
    populations = {'MANHATTAN': 1628706, 'BRONX': 1432132, 'BROOKLYN': 2582830, 'QUEENS': 2278906, 'STATEN ISLAND': 476143}

    # Initialize an empty DataFrame
    borough_df = pd.DataFrame(columns=['Borough', 'Total Crimes', 'Population', 'Crimes per Population'])

    # Drop rows with null values in the 'boro_nm' column
    df_cleaned = df.dropna(subset=['boro_nm'])

    # Calculate total number of crimes in each borough
    total_crimes = df_cleaned.groupby('boro_nm').size().reset_index(name='Total Crimes')

    # Add population data for each borough
    borough_df['Borough'] = total_crimes['boro_nm']
    borough_df['Total Crimes'] = total_crimes['Total Crimes']
    borough_df['Population'] = borough_df['Borough'].map(populations)

    # Drop rows with NaN population values
    borough_df = borough_df.dropna(subset=['Population'])

    # Calculate crimes per population ratio
    borough_df['Crimes per Population'] = borough_df['Total Crimes'] / borough_df['Population']

    # Iterate over the unique values of the 'law_cat_cd' column
    for law_cat_cd in df['law_cat_cd'].unique():
        # Filter DataFrame for the current 'law_cat_cd'
        df_law_cat_cd = df[df['law_cat_cd'] == law_cat_cd]
        # Calculate total number of crimes for the current 'law_cat_cd' in each borough
        total_crimes_law_cat_cd = df_law_cat_cd.groupby('boro_nm').size().reset_index(name=f'Total Crimes ({law_cat_cd})')
        # Merge with existing DataFrame on 'Borough' column
        borough_df = pd.merge(borough_df, total_crimes_law_cat_cd, left_on='Borough', right_on='boro_nm', how='left')

    # Fill NaN values with 0
    borough_df = borough_df.fillna(0)

    # drop 3 columns named  boro_nm_x  , boro_nm_y, boro_nm  from  borough_df
    borough_df.drop(columns=['boro_nm_x', 'boro_nm_y', 'boro_nm'], inplace=True)

    # Split the data into features (X) and target variable (y)
    X = borough_df.drop(columns=['Borough', 'Crimes per Population'])
    y = borough_df['Crimes per Population']

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize Gradient Boosting Regressor
    gb_regressor = GradientBoostingRegressor()

    # Fit the model on the training data
    gb_regressor.fit(X_train, y_train)

    # Predict on the testing data
    y_pred = gb_regressor.predict(X_test)

    # Calculate Mean Squared Error
    mse = mean_squared_error(y_test, y_pred)
    
    # Calculate accuracy based on the threshold
    threshold = 0.0001  # Adjust as needed
    accuracy = calculate_accuracy(y_test, y_pred, threshold)
    
    # Visualization: Scatter plot of actual vs predicted values
    plt.figure(figsize=(10, 6))
    plt.scatter(y_test, y_pred, color='blue')
    plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', linestyle='--')
    plt.title('Actual vs Predicted Values')
    plt.xlabel('Actual')
    plt.ylabel('Predicted')
    plt.grid(True)
    plt.tight_layout()

    # Save the plot to a buffer and encode as base64
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()

    # Assuming you have a context dictionary containing data to pass to the template
    context = {'mse': mse, 'accuracy': accuracy, 'plot_base64': image_base64}
    return render(request, 'gradient_boost_results.html', context)




def predict_probabilities(request):
    # Load the CSV file containing crime data
    csv_folder = os.path.join(settings.BASE_DIR, 'datasets')
    csv_file_path = os.path.join(csv_folder, 'dataset.csv')
    
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path)
    else:
        return HttpResponse("CSV file does not exist.")

    # Make a copy of the DataFrame
    df_copy = df.copy()

    # Convert 'cmplnt_fr_tm' column to string format
    df_copy['cmplnt_fr_tm'] = df_copy['cmplnt_fr_tm'].astype(str)

    # Convert time of crime to categorical features representing different time periods of the day
    def get_time_period(hour):
        if 0 <= hour < 6:
            return 'Night'
        elif 6 <= hour < 12:
            return 'Morning'
        elif 12 <= hour < 18:
            return 'Afternoon'
        else:
            return 'Evening'

    df_copy['time_period'] = df_copy['cmplnt_fr_tm'].str.split(':').str[0].astype(int).apply(get_time_period)

    # Drop the original 'cmplnt_fr_tm' column using .loc to modify the original DataFrame
    df_copy.loc[:, 'cmplnt_fr_tm'] = df_copy['cmplnt_fr_tm']

    # Assume 'X' is your feature matrix and 'y' is your target variable (victim race)
    X = df_copy[['latitude', 'longitude', 'boro_nm', 'vic_sex', 'vic_age_group', 'time_period', 'ofns_desc']]
    y = df_copy['vic_race']

    # Encode categorical variables
    label_encoders = {}
    for column in ['boro_nm', 'vic_sex', 'vic_age_group', 'time_period', 'ofns_desc']:
        label_encoders[column] = LabelEncoder()
        X.loc[:, column] = label_encoders[column].fit_transform(X[column])

    # Train a Random Forest Classifier
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    # Use the model to make predictions on new data
    new_data = pd.DataFrame({
        'latitude': [40.7128],
        'longitude': [-74.0060],
        'boro_nm': ['MANHATTAN'],
        'vic_sex': ['M'],
        'vic_age_group': ['25-44'],
        'time_period': ['Morning'],
        'ofns_desc': ['ASSAULT 3 & RELATED OFFENSES']
    })

    # Encode categorical variables in new data
    for column in ['boro_nm', 'vic_sex', 'vic_age_group', 'time_period', 'ofns_desc']:
        new_data[column] = label_encoders[column].transform(new_data[column])

    # Make predictions
    probabilities = model.predict_proba(new_data)

    # Display probabilities and corresponding classes
    classes = model.classes_
    predictions = [{'class': classes[i], 'probability': prob} for i, prob in enumerate(probabilities[0])]

    # dEncode categorical variables in new data
    for column in ['boro_nm', 'vic_sex', 'vic_age_group', 'time_period', 'ofns_desc']:
        new_data[column] = label_encoders[column].inverse_transform(new_data[column])

    # Assuming you have a context dictionary containing data to pass to the template
    context = {'new_data': new_data, 'predictions': predictions}
    return render(request, 'probabilities_prediction.html', context)


# Define similar views for the remaining visualizations following the same structure



# views.py


