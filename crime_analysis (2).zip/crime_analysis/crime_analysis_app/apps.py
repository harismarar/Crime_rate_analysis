from django.apps import AppConfig


class CrimeAnalysisAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crime_analysis_app'
